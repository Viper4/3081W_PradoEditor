#include "include/prado_editor.h"

PradoEditor::PradoEditor(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

PradoEditor::~PradoEditor()
{

}

